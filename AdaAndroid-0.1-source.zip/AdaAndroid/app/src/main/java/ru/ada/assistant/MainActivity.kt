package ru.ada.assistant

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.util.zip.ZipInputStream

private val Bg = Color(0xFF111318)
private val Panel = Color(0xFF1B1E26)
private val Accent = Color(0xFFC7A6FF)
private val TextMain = Color(0xFFE9E7EF)
private val TextMuted = Color(0xFF9A98A3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AdaApp(this) }
    }
}

data class ChatMessage(val text: String, val fromAda: Boolean)

@Composable
private fun AdaApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("ada", Context.MODE_PRIVATE) }
    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            addAll(loadMessages(prefs))
            if (isEmpty()) add(ChatMessage("Я на месте. Пока это первая сборка: память и импорт уже закладываем, а подключение настоящих моделей будет следующим этапом.", true))
        }
    }
    var draft by remember { mutableStateOf("") }
    var importStatus by remember { mutableStateOf("История хранится на этом устройстве") }
    var importedCount by remember { mutableIntStateOf(prefs.getInt("imported_count", 0)) }
    val scope = rememberCoroutineScope()

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                importStatus = "Разбираю архив…"
                val result = withContext(Dispatchers.IO) { importChatGPT(context, uri) }
                importedCount += result.first
                prefs.edit().putInt("imported_count", importedCount).apply()
                importStatus = result.second
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Bg, surface = Panel,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("АДА", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("личный локальный собеседник", color = TextMuted, fontSize = 12.sp)
                }
                Surface(color = Color(0xFF292332), shape = CircleShape) {
                    Text("0.1", color = Accent, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusChip("ОНЛАЙН", false)
                StatusChip("ОФФЛАЙН · ПАМЯТЬ", true)
            }
            Spacer(Modifier.height(12.dp))
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("ПАМЯТЬ И ИСТОРИЯ", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Импортировано диалогов: $importedCount", color = TextMain, fontSize = 13.sp)
                    Text(importStatus, color = TextMuted, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { importPicker.launch(arrayOf("application/zip", "application/octet-stream")) }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 5.dp)) {
                        Icon(Icons.Default.AttachFile, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Импортировать экспорт ChatGPT", fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                items(messages) { message ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromAda) Arrangement.Start else Arrangement.End) {
                        Surface(color = if (message.fromAda) Panel else Color(0xFF30283B), shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(if (message.fromAda) "АДА" else "ТЫ", color = Accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(message.text, color = TextMain, fontSize = 14.sp, lineHeight = 20.sp)
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.weight(1f)) {
                    BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp), textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 14.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent), decorationBox = { inner ->
                        if (draft.isEmpty()) Text("Напиши что-нибудь…", color = TextMuted, fontSize = 14.sp)
                        inner()
                    })
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = {
                    val text = draft.trim()
                    if (text.isNotEmpty()) {
                        messages.add(ChatMessage(text, false))
                        messages.add(ChatMessage("Сообщение сохранено локально. Настоящая языковая модель ещё не подключена, поэтому я пока не буду притворяться, что могу ответить без неё. Следующий этап: подключить облачную модель и резервную локальную.", true))
                        draft = ""
                        saveMessages(prefs, messages)
                    }
                }, modifier = Modifier.size(48.dp).background(Accent, CircleShape)) {
                    Icon(Icons.Default.Send, contentDescription = "Отправить", tint = Color(0xFF17131D))
                }
            }
        }
    }
}

@Composable
private fun StatusChip(label: String, active: Boolean) {
    Surface(color = if (active) Color(0xFF26372F) else Color(0xFF292332), shape = RoundedCornerShape(20.dp)) {
        Text(label, color = if (active) Color(0xFF9ED6B2) else Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
    }
}

private fun saveMessages(prefs: android.content.SharedPreferences, messages: List<ChatMessage>) {
    val array = JSONArray()
    messages.takeLast(500).forEach { array.put(JSONObject().put("text", it.text).put("ada", it.fromAda)) }
    prefs.edit().putString("messages", array.toString()).apply()
}

private fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> {
    val raw = prefs.getString("messages", null) ?: return emptyList()
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { ChatMessage(it.optString("text"), it.optBoolean("ada")) } }
    } catch (_: Exception) { emptyList() }
}

private fun importChatGPT(context: Context, uri: Uri): Pair<Int, String> {
    return try {
        var conversationsJson: String? = null
        context.contentResolver.openInputStream(uri).use { input ->
            if (input == null) return 0 to "Не удалось открыть файл"
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.name.endsWith("conversations.json", ignoreCase = true)) {
                        conversationsJson = zip.bufferedReader(Charsets.UTF_8).readText()
                        break
                    }
                    zip.closeEntry()
                }
            }
        }
        val json = conversationsJson ?: return 0 to "В архиве не найден conversations.json. Выбери ZIP-экспорт ChatGPT целиком."
        val array = JSONArray(json)
        val saved = context.getSharedPreferences("ada", Context.MODE_PRIVATE).getString("imports", "") ?: ""
        context.openFileOutput("chatgpt_import.json", Context.MODE_PRIVATE).use { it.write(json.toByteArray(Charsets.UTF_8)) }
        val count = array.length()
        context.getSharedPreferences("ada", Context.MODE_PRIVATE).edit().putString("imports", saved + "\n" + count).apply()
        count to "Импорт завершён. Сохранено диалогов: $count. Исходный архив не изменён."
    } catch (e: Exception) {
        0 to "Не удалось прочитать архив: ${e.message ?: "неизвестная ошибка"}"
    }
}
